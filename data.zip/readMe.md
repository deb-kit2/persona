## To - do :
 - [x] Model forward masking
 - [x] finish main.py
 - [x] adj in utils
 - [x] logging 
 - [ ] metrics
 - [x] test in main
 - [ ] T5